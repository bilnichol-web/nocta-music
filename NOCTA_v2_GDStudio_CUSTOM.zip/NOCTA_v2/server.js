import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { extname, join, normalize } from 'node:path';
import { fileURLToPath } from 'node:url';
import { GDStudioMusic } from './gdstudio.js';

const __dirname = fileURLToPath(new URL('.', import.meta.url));
const port = Number(process.env.PORT || 3000);
const music = new GDStudioMusic({
  platforms: ['netease', 'joox', 'bilibili'],
  perPlatformLimit: 8,
  fetchStream: true,
  fetchCover: true,
  fetchLyric: true,
  concurrency: 3,
});
const types = { '.html':'text/html; charset=utf-8', '.js':'text/javascript; charset=utf-8', '.css':'text/css; charset=utf-8', '.json':'application/json; charset=utf-8' };

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    if (url.pathname === '/api/search') {
      const q = (url.searchParams.get('q') || '').trim();
      if (!q || q.length > 100) { res.writeHead(400, {'Content-Type':'application/json'}); res.end(JSON.stringify({error:'Kata pencarian wajib diisi (maksimal 100 karakter).'})); return; }
      const result = await music.searchAll(q, { limit: 8, page: 1, preferredBitrate: 320 });
      // Do not return lyric text to the browser; only expose availability metadata.
      result.results = result.results.map(item => ({ ...item, lyrics: { available: Boolean(item.lyrics?.available) } }));
      res.writeHead(200, {'Content-Type':'application/json; charset=utf-8', 'Cache-Control':'no-store'});
      res.end(JSON.stringify(result));
      return;
    }
    const pathname = url.pathname === '/' ? '/index.html' : decodeURIComponent(url.pathname);
    const filePath = normalize(join(__dirname, pathname));
    if (!filePath.startsWith(__dirname)) { res.writeHead(403); res.end('Forbidden'); return; }
    const data = await readFile(filePath);
    res.writeHead(200, {'Content-Type': types[extname(filePath)] || 'application/octet-stream'});
    res.end(data);
  } catch (error) {
    const isApi = req.url?.startsWith('/api/');
    res.writeHead(isApi ? 502 : 404, {'Content-Type': isApi ? 'application/json' : 'text/plain'});
    res.end(isApi ? JSON.stringify({error: 'Layanan musik gagal dihubungi. Coba lagi nanti.'}) : 'File tidak ditemukan.');
  }
});
server.listen(port, '0.0.0.0', () => console.log(`NOCTA berjalan di http://localhost:${port}`));
