/**
* Author: Daps / Xyrcodex
* Hapus Credit Gak Bikin Lau Keliatan Jago Dawg
*
 * Supported public platforms (multi-platform):
 *   - netease   (网易云音乐, NetEase Cloud Music)
 *   - joox      (JOOX, international)
 *   - bilibili  (B站, Bilibili Music)
*
 * Usage:
 *   node gdstudio.js "<query>" [options]
 *
 * Options:
 *   --platform=<p>       daftar platform yang dipisahkan koma (default: netease,joox,bilibili)
 *   --limit=<n>          max results per platform (default: 10)
 *   --page=<n>           page number (default: 1)
 *   --bitrate=<br>       preferred bitrate 999|740|320|192|128 (default: 999)
 *   --no-stream          skip stream/download URL lookup
 *   --no-cover           skip cover image lookup
 *   --no-lyric           skip lyric lookup
 *   --output=<file>      write JSON to file
 *   --pretty             pretty-print JSON
 *   --help, -h           show this help
 *
 */

import { execFile } from "node:child_process";
import { writeFile } from "node:fs/promises";
import { argv, exit, stdout, stderr } from "node:process";

const DEFAULTS = Object.freeze({
  apiBase: "https://music-api.gdstudio.xyz/api.php",
  hostReferer: "https://music.gdstudio.xyz/",
  platforms: ["netease", "joox", "bilibili"],
  bitrateOrder: [999, 740, 320, 192, 128],
  bitrateLabels: { 999: "Hi-Res", 740: "Lossless", 320: "Exhigh", 192: "Higher", 128: "Standard" },
  coverSize: 500,
  perPlatformLimit: 10,
  page: 1,
  timeoutMs: 15000,
  userAgent:
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
});

const HEADERS = Object.freeze({
  Referer: DEFAULTS.hostReferer,
  "User-Agent": DEFAULTS.userAgent,
  "X-Requested-With": "XMLHttpRequest",
  Accept: "application/json, text/javascript, */*; q=0.01",
});

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function curlGet(targetUrl, extraHeaders = {}) {
  return new Promise((resolve, reject) => {
    const args = [
      "-sS",
      "--compressed",
      "--max-time",
      String(Math.ceil(DEFAULTS.timeoutMs / 1000)),
      "--retry",
      "0",
      "-w",
      "\n__HTTP_STATUS__:%{http_code}",
    ];
    for (const [key, value] of Object.entries(HEADERS)) args.push("-H", `${key}: ${value}`);
    for (const [key, value] of Object.entries(extraHeaders)) args.push("-H", `${key}: ${value}`);
    args.push(targetUrl);
    execFile("curl", args, { maxBuffer: 16 * 1024 * 1024, windowsHide: true }, (err, stdoutData, stderrData) => {
      if (err) {
        reject(new Error(`curl failed: ${err.message}${stderrData ? ` (${stderrData.trim()})` : ""}`));
        return;
      }
      const raw = stdoutData.toString();
      const marker = "\n__HTTP_STATUS__:";
      const idx = raw.lastIndexOf(marker);
      const status = idx >= 0 ? Number(raw.slice(idx + marker.length)) : 0;
      const body = idx >= 0 ? raw.slice(0, idx) : raw;
      resolve({ status, body });
    });
  });
}

async function fetchJson(url, retries = 2) {
  let lastErr = null;
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      const { status, body } = await curlGet(url);
      if (status === 0) throw new Error("curl returned no status");
      if (status < 200 || status >= 300) {
        throw new Error(`HTTP ${status}: ${body.slice(0, 200)}`);
      }
      try {
        return JSON.parse(body);
      } catch {
        throw new Error(`Non-JSON response: ${body.slice(0, 200)}`);
      }
    } catch (err) {
      lastErr = err;
      if (attempt < retries) await sleep(500 * (attempt + 1));
    }
  }
  throw lastErr;
}

function buildUrl(base, params) {
  const qs = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) {
    if (value === undefined || value === null) continue;
    qs.append(key, String(value));
  }
  return `${base}?${qs.toString()}`;
}

function jsEncodeURIComponent(value) {
  return encodeURIComponent(String(value))
    .replace(/\(/g, "%28")
    .replace(/\)/g, "%29")
    .replace(/\*/g, "%2A")
    .replace(/'/g, "%27")
    .replace(/!/g, "%21");
}

function toMb(bytes) {
  if (!bytes || typeof bytes !== "number") return null;
  return Number((bytes / 1024 / 1024).toFixed(2));
}

function detectFormat(url, br) {
  if (!url) return null;
  const lower = url.toLowerCase();
  if (lower.includes(".flac") || lower.includes("audio/flac")) return "flac";
  if (lower.includes(".m4a") || lower.includes("audio/mp4") || lower.includes("audio/m4a")) return "m4a";
  if (lower.includes(".mp3") || lower.includes("audio/mpeg")) return "mp3";
  if (lower.includes(".m4s") || lower.includes(".mp4")) return "m4a";
  if (lower.includes(".ogg") || lower.includes("audio/ogg")) return "ogg";
  if (lower.includes(".wav") || lower.includes("audio/wav")) return "wav";
  return br >= 740 ? "flac" : "mp3";
}

function normalizeUrl(rawUrl, source) {
  if (!rawUrl || typeof rawUrl !== "string") return null;
  let url = rawUrl.trim();
  if (!url) return null;
  if (url.startsWith("//")) url = "https:" + url;
  if (source === "kuwo" && url.includes("kuwo.cn")) {
    const match = url.match(/:\/\/(.*?)(?=\.kuwo\.cn)/);
    if (match) {
      const subdomain = match[1];
      const newSubdomain = subdomain.replace(/\./g, "-");
      url = url.replace(`://${subdomain}.kuwo.cn`, `://${newSubdomain}.kuwo.cn`);
    }
  }
  if (source === "bilibili" && url.startsWith("http:")) {
    url = "https:" + url.slice(5);
  }
  return url;
}

function sanitizeString(value) {
  if (value === null || value === undefined) return null;
  if (Array.isArray(value)) return value.map((v) => sanitizeString(v)).filter(Boolean);
  if (typeof value === "string") return value.trim() || null;
  return value;
}

function buildSongRecord(searchItem, detail, source) {
  const stream = detail.stream;
  const cover = detail.cover;
  const lyric = detail.lyric;
  return {
    platform: source,
    id: sanitizeString(searchItem.id),
    url_id: sanitizeString(searchItem.url_id),
    lyric_id: sanitizeString(searchItem.lyric_id),
    pic_id: sanitizeString(searchItem.pic_id),
    title: sanitizeString(searchItem.name),
    artists: sanitizeString(searchItem.artist) || [],
    album: sanitizeString(searchItem.album) || null,
    provider: sanitizeString(searchItem.from) || "music.gdstudio.xyz",
    stream: stream.available
      ? {
          url: stream.url,
          format: stream.format,
          bitrate: stream.bitrate,
          bitrate_label: stream.bitrateLabel,
          size_bytes: stream.sizeBytes,
          size_mb: stream.sizeMb,
          available: true,
        }
      : { available: false, reason: stream.reason || "no_stream_url" },
    cover: cover.available
      ? { url: cover.url, size: cover.size, available: true }
      : { available: false, reason: cover.reason || "no_cover" },
    lyrics: lyric.available
      ? {
          lyric: lyric.lyric,
          translation: lyric.translation,
          chars: lyric.chars,
          available: true,
        }
      : { available: false, reason: lyric.reason || "no_lyric" },
    raw_search: searchItem,
  };
}

class GDStudioMusic {
  constructor(options = {}) {
    this.apiBase = options.apiBase || DEFAULTS.apiBase;
    this.platforms = options.platforms || [...DEFAULTS.platforms];
    this.bitrateOrder = options.bitrateOrder || [...DEFAULTS.bitrateOrder];
    this.coverSize = options.coverSize || DEFAULTS.coverSize;
    this.perPlatformLimit = options.perPlatformLimit || DEFAULTS.perPlatformLimit;
    this.fetchStream = options.fetchStream !== false;
    this.fetchCover = options.fetchCover !== false;
    this.fetchLyric = options.fetchLyric !== false;
    this.concurrency = options.concurrency || 4;
  }

  async search(keyword, source, page = 1, count = this.perPlatformLimit) {
    const params = {
      types: "search",
      source,
      name: keyword,
      count: String(count),
      pages: String(page),
    };
    const url = buildUrl(this.apiBase, params);
    const data = await fetchJson(url);
    if (!Array.isArray(data)) return [];
    return data.slice(0, count);
  }

  async getSongUrl(urlId, source, preferredBitrate = this.bitrateOrder[0]) {
    const orderedBitrates = [
      preferredBitrate,
      ...this.bitrateOrder.filter((br) => br !== preferredBitrate),
    ];
    for (const br of orderedBitrates) {
      const params = { types: "url", source, id: urlId, br: String(br) };
      const url = buildUrl(this.apiBase, params);
      try {
        const data = await fetchJson(url);
        if (!data || typeof data !== "object") continue;
        const rawUrl = data.url;
        const normalized = normalizeUrl(rawUrl, source);
        const sizeBytes = typeof data.size === "number" ? data.size : Number(data.size) || 0;
        const actualBr = typeof data.br === "number" ? data.br : Number(data.br) || br;
        if (normalized && sizeBytes > 0 && actualBr > 0) {
          return {
            available: true,
            url: normalized,
            format: detectFormat(normalized, actualBr),
            bitrate: actualBr,
            bitrateLabel: DEFAULTS.bitrateLabels[br] || DEFAULTS.bitrateLabels[actualBr] || "Unknown",
            sizeBytes,
            sizeMb: toMb(sizeBytes),
            raw: data,
          };
        }
      } catch {
        continue;
      }
    }
    return { available: false, reason: "no_stream_url" };
  }

  async getCover(picId, source, size = this.coverSize) {
    if (!picId) return { available: false, reason: "missing_pic_id" };
    if (source === "kuwo" && /^\d/.test(String(picId))) {
      const stripped = String(picId).replace(/^120\//, "");
      const path = String(picId).startsWith("120/") ? `${size}/${stripped}` : stripped;
      return {
        available: true,
        url: `http://img1.kwcdn.kuwo.cn/star/albumcover/${path}`,
        size,
      };
    }
    if (source === "bilibili" && /^https?:\/\//.test(String(picId))) {
      return { available: true, url: String(picId), size };
    }
    const params = { types: "pic", source, id: picId, size: String(size) };
    const url = buildUrl(this.apiBase, params);
    try {
      const data = await fetchJson(url);
      if (data && data.url) {
        return { available: true, url: normalizeUrl(data.url, source), size };
      }
      return { available: false, reason: "empty_cover_response" };
    } catch (err) {
      return { available: false, reason: `cover_error:${err.message}` };
    }
  }

  async getLyric(lyricId, source) {
    if (!lyricId) return { available: false, reason: "missing_lyric_id" };
    const params = { types: "lyric", source, id: lyricId };
    const url = buildUrl(this.apiBase, params);
    try {
      const data = await fetchJson(url);
      const lyric = data && typeof data.lyric === "string" ? data.lyric.trim() : "";
      const translation = data && typeof data.tlyric === "string" ? data.tlyric.trim() : "";
      if (!lyric || lyric === "NULL" || lyric === "null" || lyric.includes("歌词获取失败")) {
        return { available: false, reason: "empty_lyric" };
      }
      return {
        available: true,
        lyric,
        translation: translation || null,
        chars: lyric.length,
        raw: data,
      };
    } catch (err) {
      return { available: false, reason: `lyric_error:${err.message}` };
    }
  }

  async getSongDetails(searchItem, source, preferredBitrate) {
    const [stream, cover, lyric] = await Promise.allSettled([
      this.fetchStream
        ? this.getSongUrl(searchItem.url_id, source, preferredBitrate)
        : Promise.resolve({ available: false, reason: "skipped" }),
      this.fetchCover
        ? this.getCover(searchItem.pic_id, source)
        : Promise.resolve({ available: false, reason: "skipped" }),
      this.fetchLyric
        ? this.getLyric(searchItem.lyric_id, source)
        : Promise.resolve({ available: false, reason: "skipped" }),
    ]);
    return {
      stream: stream.status === "fulfilled" ? stream.value : { available: false, reason: stream.reason?.message },
      cover: cover.status === "fulfilled" ? cover.value : { available: false, reason: cover.reason?.message },
      lyric: lyric.status === "fulfilled" ? lyric.value : { available: false, reason: lyric.reason?.message },
    };
  }

  async searchOnePlatform(keyword, source, options = {}) {
    const page = options.page || 1;
    const limit = options.limit || this.perPlatformLimit;
    const preferredBitrate = options.preferredBitrate || this.bitrateOrder[0];
    try {
      const searchResults = await this.search(keyword, source, page, limit);
      if (!searchResults.length) {
        return { platform: source, ok: true, results: [], searched_at: new Date().toISOString() };
      }
      const limited = searchResults.slice(0, limit);
      const records = [];
      const queue = limited.map((item) => ({ item, source }));
      async function worker() {
        while (queue.length) {
          const next = queue.shift();
          if (!next) break;
          try {
            const detail = await this.getSongDetails(next.item, next.source, preferredBitrate);
            records.push(buildSongRecord(next.item, detail, next.source));
          } catch (err) {
            records.push({
              platform: next.source,
              id: next.item.id,
              title: next.item.name,
              error: err.message,
              raw_search: next.item,
            });
          }
        }
      }
      const workers = Array.from({ length: Math.min(this.concurrency, limited.length) }, () =>
        worker.call(this)
      );
      await Promise.all(workers);
      return {
        platform: source,
        ok: true,
        results: records,
        searched_at: new Date().toISOString(),
      };
    } catch (err) {
      return {
        platform: source,
        ok: false,
        error: err.message,
        results: [],
        searched_at: new Date().toISOString(),
      };
    }
  }

  async searchAll(keyword, options = {}) {
    const platforms = options.platforms || this.platforms;
    const startedAt = new Date().toISOString();
    const platformReports = await Promise.all(
      platforms.map((source) => this.searchOnePlatform(keyword, source, options))
    );
    const allResults = [];
    const platformSummaries = [];
    for (const report of platformReports) {
      platformSummaries.push({
        platform: report.platform,
        ok: report.ok,
        error: report.error || null,
        count: report.results.length,
        searched_at: report.searched_at,
      });
      for (const record of report.results) {
        allResults.push(record);
      }
    }
    return {
      query: keyword,
      searched_at: startedAt,
      finished_at: new Date().toISOString(),
      api_base: this.apiBase,
      platforms_searched: platforms,
      platform_summaries: platformSummaries,
      total_results: allResults.length,
      results: allResults,
    };
  }
}

function parseArgs(args) {
  const opts = {
    query: null,
    platforms: [...DEFAULTS.platforms],
    limit: DEFAULTS.perPlatformLimit,
    page: 1,
    bitrate: DEFAULTS.bitrateOrder[0],
    fetchStream: true,
    fetchCover: true,
    fetchLyric: true,
    output: null,
    pretty: true,
  };
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    if (arg === "-h" || arg === "--help") {
      opts.help = true;
    } else if (arg.startsWith("--platform=")) {
      opts.platforms = arg.slice("--platform=".length).split(",").map((s) => s.trim()).filter(Boolean);
    } else if (arg.startsWith("--limit=")) {
      opts.limit = Number(arg.slice("--limit=".length)) || opts.limit;
    } else if (arg.startsWith("--page=")) {
      opts.page = Number(arg.slice("--page=".length)) || 1;
    } else if (arg.startsWith("--bitrate=")) {
      opts.bitrate = Number(arg.slice("--bitrate=".length)) || opts.bitrate;
    } else if (arg.startsWith("--output=")) {
      opts.output = arg.slice("--output=".length);
    } else if (arg === "--no-stream") {
      opts.fetchStream = false;
    } else if (arg === "--no-cover") {
      opts.fetchCover = false;
    } else if (arg === "--no-lyric") {
      opts.fetchLyric = false;
    } else if (arg === "--pretty") {
      opts.pretty = true;
    } else if (arg === "--no-pretty") {
      opts.pretty = false;
    } else if (!arg.startsWith("-") && opts.query === null) {
      opts.query = arg;
    }
  }
  return opts;
}

function printHelp() {
  stdout.write(`gdstudio.js — Scrape Music

Usage:
  node gdstudo.js "<query>" [options]

Options:
  --platform=<p>      platform yang dipisahkan koma (default: netease,joox,bilibili)
  --limit=<n>         max results per platform (default: 10)
  --page=<n>          page number (default: 1)
  --bitrate=<br>      preferred bitrate 999|740|320|192|128 (default: 999)
  --no-stream         skip stream/download URL lookup
  --no-cover          skip cover image lookup
  --no-lyric          skip lyric lookup
  --output=<file>     write JSON output to file
  --pretty             pretty-print JSON
  --no-pretty         minify JSON
  -h, --help          show this help

Examples:
  node gdstudio.js "jay chou"
  node gdstudio.js "love song" --platform=netease --limit=5
  node gdstudio.js "周杰伦" --output=out.json
`);
}

async function main() {
  const opts = parseArgs(argv.slice(2));
  if (opts.help) {
    printHelp();
    return 0;
  }
  if (!opts.query) {
    stderr.write("Error: search query is required.\n");
    printHelp();
    return 1;
  }
  const music = new GDStudioMusic({
    platforms: opts.platforms,
    perPlatformLimit: opts.limit,
    fetchStream: opts.fetchStream,
    fetchCover: opts.fetchCover,
    fetchLyric: opts.fetchLyric,
  });
  const result = await music.searchAll(opts.query, {
    page: opts.page,
    limit: opts.limit,
    preferredBitrate: opts.bitrate,
    platforms: opts.platforms,
  });
  const json = opts.pretty ? JSON.stringify(result, null, 2) : JSON.stringify(result);
  if (opts.output) {
    await writeFile(opts.output, json, "utf8");
    stdout.write(`Wrote ${result.total_results} results to ${opts.output}\n`);
  } else {
    stdout.write(json + "\n");
  }
  return 0;
}

const isMain = (() => {
  try {
    return import.meta.url === `file://${process.argv[1]}`;
  } catch {
    return false;
  }
})();

if (isMain) {
  main().then((code) => exit(code || 0)).catch((err) => {
    stderr.write(`Fatal error: ${err.message}\n`);
    exit(1);
  });
}

export { GDStudioMusic, DEFAULTS, HEADERS };
export default GDStudioMusic;
